#include <msp430.h>
#include <driverlib.h>

void initGPIO()
{
    // LED: P1.0 ��k�� olarak ayarlan�r ve ba�lang��ta s�nd�r�l�r
    GPIO_setAsOutputPin(GPIO_PORT_P10, GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P10, GPIO_PIN7);
}

void initUART()
{
    // UART pin konfig�rasyonu: TX = P3.3, RX = P3.4
    GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P9, GPIO_PIN4); // TX
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P9, GPIO_PIN5);  // RX

    // UART yap�land�rmas� (9600 baud i�in SMCLK = 1 MHz'e g�re)
    USCI_A_UART_initParam uartConfig = {
        USCI_A_UART_CLOCKSOURCE_SMCLK,
        6,     // UCBRx
        8,     // UCBRFx
        0x20,  // UCBRSx
        USCI_A_UART_NO_PARITY,
        USCI_A_UART_LSB_FIRST,
        USCI_A_UART_ONE_STOP_BIT,
        USCI_A_UART_MODE,
        USCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION
    };

    USCI_A_UART_init(USCI_A2_BASE, &uartConfig);
    USCI_A_UART_enable(USCI_A2_BASE);

    USCI_A_UART_clearInterrupt(USCI_A2_BASE, USCI_A_UART_RECEIVE_INTERRUPT);
    USCI_A_UART_enableInterrupt(USCI_A2_BASE, USCI_A_UART_RECEIVE_INTERRUPT);
}

int main(void)
{
    WDT_A_hold(WDT_A_BASE); // Watchdog Timer durduruluyor

    initGPIO();
    initUART();

    __enable_interrupt(); // Global interrupt'lar� a�

    while (1) {
        __no_operation(); // Beklemede kal
    }
}

// UART kesmesi: gelen veriyi al ve LED�i kontrol et
#pragma vector=USCI_A2_VECTOR
__interrupt void USCI_A2_ISR(void)
{
    switch (__even_in_range(UCA2IV, 4))
    {
        case 2: // RXIFG
        {
            char c = USCI_A_UART_receiveData(USCI_A2_BASE);
            if (c == '1') {
                GPIO_setOutputHighOnPin(GPIO_PORT_P10, GPIO_PIN7); // LED ON
            } else if (c == '2') {
                GPIO_setOutputLowOnPin(GPIO_PORT_P10, GPIO_PIN7); // LED OFF
            }
            break;
        }
        default:
            break;
    }
}
