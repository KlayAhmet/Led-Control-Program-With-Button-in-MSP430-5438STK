﻿namespace WindowsFormsApp10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.Windows.Forms.Button btnLED1;
        private System.Windows.Forms.Button btnLED2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Label lblStatus;

        private void InitializeComponent()
        {
            this.btnLED1 = new System.Windows.Forms.Button();
            this.btnLED2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btnOpen = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLED1
            // 
            this.btnLED1.Location = new System.Drawing.Point(30, 71);
            this.btnLED1.Name = "btnLED1";
            this.btnLED1.Size = new System.Drawing.Size(75, 33);
            this.btnLED1.TabIndex = 0;
            this.btnLED1.Text = "On";
            this.btnLED1.UseVisualStyleBackColor = true;
            this.btnLED1.Click += new System.EventHandler(this.btnLED1_Click);
            // 
            // btnLED2
            // 
            this.btnLED2.Location = new System.Drawing.Point(120, 71);
            this.btnLED2.Name = "btnLED2";
            this.btnLED2.Size = new System.Drawing.Size(75, 33);
            this.btnLED2.TabIndex = 1;
            this.btnLED2.Text = "Off";
            this.btnLED2.UseVisualStyleBackColor = true;
            this.btnLED2.Click += new System.EventHandler(this.btnLED2_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Location = new System.Drawing.Point(30, 20);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(160, 20);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 23);
            this.btnOpen.TabIndex = 3;
            this.btnOpen.Text = "Connect";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(27, 44);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(95, 13);
            this.lblStatus.TabIndex = 4;
            this.lblStatus.Text = "Port Status: Offline";
            this.lblStatus.Click += new System.EventHandler(this.lblStatus_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(263, 131);
            this.Controls.Add(this.btnLED1);
            this.Controls.Add(this.btnLED2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.lblStatus);
            this.Name = "Form1";
            this.Text = "MSP430 LED Control";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
    

