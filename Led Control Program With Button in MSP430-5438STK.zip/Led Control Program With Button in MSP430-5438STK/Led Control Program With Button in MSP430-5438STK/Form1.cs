﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Led_Control_Program_With_Button_in_MSP430_5438STK
{
    public partial class Form1 : Form
    {
        SerialPort serialPort = new SerialPort();

        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.AddRange(SerialPort.GetPortNames());
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (!serialPort.IsOpen)
            {
                serialPort.PortName = comboBox1.SelectedItem.ToString();
                serialPort.BaudRate = 9600;
                serialPort.Open();
                lblStatus.Text = "Connected";
            }
        }

        private void btnLED1_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen)
                serialPort.Write("1");
        }

        private void btnLED2_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen)
                serialPort.Write("2");
        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }
    }
}
